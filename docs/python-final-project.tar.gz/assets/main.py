import asyncio
import pygame
import sys
import random
from pygame import mixer

pygame.init()
pygame.mixer.init()

width, height = 1500, 800
screen = pygame.display.set_mode((width, height))
pygame.display.set_caption("Blitzshot Game")
clock = pygame.time.Clock()
FPS = 60

# colors
YELLOW = (255, 255, 0)
RED = (255, 0, 0)
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)

# fonts (loaded once)
score_time_font = pygame.font.Font("NovaSlim-Regular.ttf", 20)
title_game_font = pygame.font.Font("NovaSlim-Regular.ttf", 120)
gameover_font = pygame.font.Font("NovaSlim-Regular.ttf", 120)
highest_score_font = pygame.font.Font("NovaSlim-Regular.ttf", 40)
end_score_font = pygame.font.Font("NovaSlim-Regular.ttf", 40)

# images (loaded once, not every frame)
play_button = pygame.image.load('Play Button.png').convert()
play_button_rect = play_button.get_rect(topleft=(600, 350))

quit_button = pygame.image.load('Quit Button.png').convert()
quit_button_rect_menu = quit_button.get_rect(topleft=(600, 500))
quit_button_rect_end = quit_button.get_rect(topleft=(600, 580))

newgame_button = pygame.image.load('New game Button.png').convert()
newgame_button_rect = newgame_button.get_rect(topleft=(600, 430))

# sounds (pygbag/web requires OGG, not MP3)
hit_sound = mixer.Sound('hit-someting-6037.ogg')
gameover_sound = mixer.Sound('elektron-mission-accomplished-160914.ogg')
mixer.music.load('metal-blues-120-bpm-loop-15519.ogg')

# game state
state = "menu"   # "menu" | "game" | "gameover"
score = 0
highest_score = 0
target_radius = 50
target_speed = 5
start_ticks = 0
targets = []


def new_targets():
    return [
        (random.randint(target_radius, width - target_radius),
         random.randint(target_radius, height - target_radius))
        for _ in range(3)
    ]


def draw_targets():
    for target in targets:
        pygame.draw.circle(screen, YELLOW, target, target_radius)


def crossaim():
    pos = pygame.mouse.get_pos()
    long = 10
    color = RED
    pygame.draw.line(screen, color, (pos[0], pos[1]), (pos[0], pos[1] - long), 2)
    pygame.draw.line(screen, color, (pos[0], pos[1]), (pos[0] + long, pos[1]), 2)
    pygame.draw.line(screen, color, (pos[0], pos[1]), (pos[0], pos[1] + long), 2)
    pygame.draw.line(screen, color, (pos[0], pos[1]), (pos[0] - long, pos[1]), 2)


def shoot(target, pos):
    x, y = target
    distance = ((x - pos[0]) ** 2 + (y - pos[1]) ** 2) ** 0.5
    return distance <= target_radius


def showScore():
    scoreText = score_time_font.render("Score : " + str(score), True, WHITE)
    screen.blit(scoreText, (10, 10))


def update_highest_score(current_score):
    # NOTE: file.txt persistence only lasts for the current browser session
    # in pygbag's virtual filesystem; it resets on page reload.
    global highest_score
    try:
        with open('file.txt', 'r') as f:
            saved = int(f.readline())
    except (FileNotFoundError, ValueError):
        saved = 0
    highest_score = max(saved, current_score)
    try:
        with open('file.txt', 'w') as f:
            f.write(str(highest_score))
    except OSError:
        pass
    return highest_score


def showHighest_score():
    hsText = highest_score_font.render("Highest score : " + str(highest_score), True, YELLOW)
    screen.blit(hsText, (550, 350))


def show_time():
    elapsed_time = (pygame.time.get_ticks() - start_ticks) // 1000
    remaining_time = 20 - elapsed_time
    timer_text = score_time_font.render("Time: " + str(remaining_time) + "s", True, WHITE)
    screen.blit(timer_text, (700, 10))


def start_new_game():
    global score, target_radius, target_speed, start_ticks, targets, state
    score = 0
    target_radius = 50
    target_speed = 5
    start_ticks = pygame.time.get_ticks()
    targets = new_targets()
    mixer.music.play(-1)
    state = "game"


async def main():
    global state, score, target_radius, target_speed, targets, start_ticks

    while True:
        # ---- event handling ----
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.MOUSEBUTTONDOWN:
                mouse_pos = pygame.mouse.get_pos()

                if state == "menu":
                    hit_sound.play()
                    if play_button_rect.collidepoint(mouse_pos):
                        start_new_game()
                    elif quit_button_rect_menu.collidepoint(mouse_pos):
                        pygame.quit()
                        sys.exit()

                elif state == "game":
                    hit_sound.play()
                    hit_target = False
                    for i, target in enumerate(targets):
                        if shoot(target, mouse_pos):
                            score += 10
                            targets[i] = (
                                random.randint(target_radius, width - target_radius),
                                random.randint(target_radius, height - target_radius),
                            )
                            hit_target = True
                    if not hit_target:
                        score -= 4

                elif state == "gameover":
                    hit_sound.play()
                    if newgame_button_rect.collidepoint(mouse_pos):
                        start_new_game()
                    elif quit_button_rect_end.collidepoint(mouse_pos):
                        pygame.quit()
                        sys.exit()

        # ---- drawing / logic per state ----
        screen.fill(BLACK)

        if state == "menu":
            pygame.mouse.set_visible(True)
            title_game_Text = title_game_font.render("BLITZSHOT", True, YELLOW)
            screen.blit(title_game_Text, (500, 150))
            screen.blit(play_button, play_button_rect)
            screen.blit(quit_button, quit_button_rect_menu)

        elif state == "game":
            pygame.mouse.set_visible(False)
            draw_targets()
            crossaim()
            showScore()
            show_time()

            if score > 50:
                target_radius = 30
            if score > 100:
                for i in range(len(targets)):
                    if targets[i][0] - target_radius <= 0 or targets[i][0] + target_radius >= width:
                        target_speed = -target_speed
                    targets[i] = (targets[i][0] + target_speed, targets[i][1])

            elapsed_time = (pygame.time.get_ticks() - start_ticks) // 1000
            if elapsed_time >= 20:
                mixer.music.stop()
                gameover_sound.play()
                update_highest_score(score)
                state = "gameover"

        elif state == "gameover":
            pygame.mouse.set_visible(True)
            showHighest_score()
            scoreText = end_score_font.render("Score : " + str(score), True, WHITE)
            screen.blit(scoreText, (650, 250))
            display_game_over = gameover_font.render("GAME OVER", True, RED)
            screen.blit(display_game_over, (400, 80))
            screen.blit(newgame_button, newgame_button_rect)
            screen.blit(quit_button, quit_button_rect_end)

        pygame.display.flip()
        clock.tick(FPS)
        await asyncio.sleep(0)  # required by pygbag - yields control to the browser


asyncio.run(main())